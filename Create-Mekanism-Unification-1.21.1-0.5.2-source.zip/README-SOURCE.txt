Source snapshot for 0.5.0. Java entrypoint registers six dirty/clean slurry pairs through Mekanism ChemicalDeferredRegister. Resources contain all recipe JSON and previous compatibility recipes.
