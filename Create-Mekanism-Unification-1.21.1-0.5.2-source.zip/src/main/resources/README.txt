Create x Mekanism Unification 0.5.0 - Minecraft 1.21.1 / NeoForge

0.5.0 adds registered dirty/clean Mekanism slurries and true slurry-based 5x ore processing for:
- Zinc
- Reggarfonite
- Platinum
- Nickel
- Aluminum
- Cobalt

5x ore path:
Ore + Sulfuric Acid -> 1000 mB Dirty Slurry -> Chemical Washer -> 1000 mB Clean Slurry -> Chemical Crystallizer (5 x 200 mB) -> 5 Crushed Raw -> Smelting -> 5 Ingots.

Existing tested 2x, 3x and 4x recipes from 0.4.1 are retained.
This is a test build. Back up your world before testing and do not keep older CMU versions installed at the same time.
