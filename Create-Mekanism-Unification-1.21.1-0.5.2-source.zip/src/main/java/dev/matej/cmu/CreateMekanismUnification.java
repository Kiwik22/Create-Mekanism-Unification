package dev.matej.cmu;
import mekanism.common.registration.impl.ChemicalDeferredRegister;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;

@Mod(CreateMekanismUnification.MODID)
public final class CreateMekanismUnification {
    public static final String MODID = "create_mekanism_unification";
    private static final ChemicalDeferredRegister CHEMICALS = new ChemicalDeferredRegister(MODID);
    static {
        slurry("zinc", 0xB9C7A3);
        slurry("reggarfonite", 0xA75D45);
        slurry("platinum", 0xD8E8E8);
        slurry("nickel", 0xC8B878);
        slurry("aluminum", 0xD7DDE1);
        slurry("cobalt", 0x4777B8);
    }
    private static void slurry(String name, int tint) {
        CHEMICALS.registerSlurry(name, builder -> builder.tint(tint));
    }
    public CreateMekanismUnification(IEventBus modBus) { CHEMICALS.register(modBus); }
}
